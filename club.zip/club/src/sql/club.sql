drop database if exists club;
create database club;
use club;

drop table if exists socios;
drop table if exists actividades;
drop table if exists entrenadores;

create table actividades(
id int auto_increment primary key,
    nombre varchar(25) not null,
    entrenador varchar(25) not null,
    dia enum('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES'),
    horario enum('MAÑANA','TARDE','NOCHE')
);

create table socios(
id int auto_increment primary key,
    nombre varchar(25) not null,
    apellido varchar(25) not null,
    edad int,
    idActividades int not null
);

create table entrenadores (
id int auto_increment primary key,
    nombre varchar(25) not null,
    apellido varchar(25) not null,
    edad int,
    idActividades int not null);

alter table socios
add constraint FK_socios_actividades
    foreign key(idActividades)
    references actividades(id);
   
alter table entrenadores
add constraint FK_entrenadores_actividades
    foreign key(idActividades)
    references actividades(id);
   
