INSERT INTO socios (nombre, apellido, edad, idActividades) VALUES
    ('Jorge', 'Pérez', 30, 1),
    ('Pedro', 'González', 25, 2),
    ('Diego', 'Torres', 35, 3),
    ('Axel', 'Rose', 28, 4),
    ('Chayanne', 'Ramírez', 32, 5);   

    -- nombre de socios inscriptos en futbol
SELECT s.nombre
FROM socios s
INNER JOIN actividades a ON s.idActividades = a.id
WHERE a.nombre = 'Futbol';

    -- nombre de socios inscriptos en boxeo
SELECT s.nombre
FROM socios s
INNER JOIN actividades a ON s.idActividades = a.id
WHERE a.nombre = 'Boxeo';

    -- numero de socios por actividad
SELECT a.nombre AS actividad, COUNT(s.id) AS total_socios
FROM actividades a
LEFT JOIN socios s ON a.id = s.idActividades
GROUP BY a.nombre;