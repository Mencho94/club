INSERT INTO entrenadores (nombre, apellido, edad, idActividades) VALUES
    ('Enzo', 'Martinez', 40, 1),
    ('Roman', 'Romano', 35, 2),
    ('Leo', 'Rodriguez', 38, 3),
    ('Lara', 'Fernández', 33, 4),
    ('Laura', 'Fernández', 42, 5);

-- nombre de los entrenadores y la cantidad de socios inscritos en cada una de sus actividades:

SELECT e.nombre, COUNT(s.id) AS total_socios
FROM entrenadores e
INNER JOIN actividades a ON e.idActividades = a.id
LEFT JOIN socios s ON a.id = s.idActividades
GROUP BY e.nombre;

-- nombre de los entrenadores y las actividades que desarrollan en el horario de la tarde
SELECT e.nombre, a.nombre AS actividad
FROM entrenadores e
INNER JOIN actividades a ON e.idActividades = a.id
WHERE a.horario = 'TARDE';