import entities.Actividades;
import entities.Entrenadores;
import entities.Socios;
import enums.Dias;
import enums.Horarios;
import repositories.ActividadesRepository;
import repositories.EntrenadoresRepository;
import repositories.SociosRepository;

public class TestRepository {

    public static void main(String[] args) {
        ActividadesRepository ar=new ActividadesRepository();

        Actividades Actividades=new Actividades("Futbol","Martinez",Dias.LUNES,Horarios.MAÑANA);

        ar.save(Actividades);

        System.out.println(Actividades);

        ar.getAll().forEach(System.out::println);
        System.out.println("******************************");
        System.out.println(ar.getById(1));
        System.out.println("******************************");
        ar.getLikeTitulo("Futbol").forEach(System.out::println);

        SociosRepository sr=new SociosRepository();
        Socios Socios=new Socios("Jorge","Perez",30,1);
        sr.save(socios);
        System.out.println(socios);

        System.out.println("******************************");
        sr.getAll().forEach(System.out::println);
        System.out.println("******************************");
        System.out.println(ar.getById(1));
        System.out.println("******************************");
        ar.getLikeApellido("pe").forEach(System.out::println);
        
   } 
    
}
