package club.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import club.connectors;
import club.entities;

public class EntrenadoresRepository {
    private Connection conn = Connector.getConnection();
    
    public void save(Entrenadores entrenadores) {
        if (entrenadores == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into entrenadores (nombre, apellido, edad, idActividad) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, entrenadores.getNombre());
            ps.setString(2, entrenadores.getApellido());
            ps.setInt(3, entrenadores.getEdad());
            ps.setInt(4, entrenadores.getIdActividades());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                entrenadores.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Entrenadores> getAll() {
        List<Entrenadores> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from entrenadores")) {
            while (rs.next()) {
                list.add(new Entrenadores(
                        rs.getInt("id"),            // id
                        rs.getString("nombre"),     // nombre
                        rs.getString("apellido"),   // apellido
                        rs.getInt("edad"),          // edad
                        rs.getInt("idActividad")        // idActividad
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Entrenadores getById(int id) {
        return getAll()
                .stream()
                .filter(a -> a.getId() == id)
                .findFirst()
                .orElse(new Entrenadores());
    }

    public List<Entrenadores>getLikeApellido(String apellido){
        if(apellido==null) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(a->a.getEntrenadores().toLowerCase().contains(apellido.toLowerCase()))
                    .toList();      //JDK 16 o sup
    }
}



