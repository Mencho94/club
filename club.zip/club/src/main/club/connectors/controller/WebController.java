public class WebController {
    @Controller
public class WebController {
    
    private ActividadesRepository actividadesRepository=new ActividadesRepository();
    private SociosRepository sociosRepository=new SociosRepository();
    private String mensajeActividades="Ingrese una nueva Actividad!";
    private String mensajeActividades="Ingrese un nuevo Socio!";

    @GetMapping("/")
    public String getIndex(){
        return "index";
    }

    @GetMapping("/actividades")
    public String getActividades(@RequestParam(name="buscarNombre", required = false, defaultValue="") String buscarNombre,
                                 Model model){
        model.addAttribute("mensajeActividades", mensajeActividades);
        model.addAttribute("actividades", new Actividades());
        //model.addAttribute("cursos", actividadesRepository.getAll());
        model.addAttribute("likeNombre", actividadesRepository.getLikeNombre(buscarNombre));
        return "actividades";
    }

    @GetMapping("/socios")
    public String getSocios(@RequestParam(name="buscarApellido", required = false, defaultValue="") String buscarApellido,
                    Model model){
        model.addAttribute("mensajeSocios", mensajeSocios);
        model.addAttribute("socios", new Socios());
        model.addAttribute("likeApellido", sociosRepository.getLikeApellido(buscarApellido));
        model.addAttribute("actividades", actividadesRepository.getAll());
        return "socios";
    }

    @PostMapping("/saveActividades")
    public String save(@ModelAttribute Actividades actividades){
        try {
            actividadesRepository.save(actividades);
            mensajeActividades="Se guardo la actividad id: "+actividades.getId();
        } catch (Exception e) {
            mensajeActividades="Ocurrio un error";
        }
        return "redirect:actividades";
    }

    @PostMapping("/saveSocios")
    public String save(@ModelAttribute Socios socios){
        try {
            sociosRepository.save(socios);
            mensajeSocios="Se guardo el socio id: "+socio.getId();
        } catch (Exception e) {
            mensajeSocios="Ocurrio un error";
        }
        return "redirect:socios";
    }
    }
}

